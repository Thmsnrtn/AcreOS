# Complete US County GIS Portal Directory

## Overview
This comprehensive directory contains GIS (Geographic Information System) portal information for counties across all 50 United States. The data has been compiled from multiple sources including state government websites, academic institutions, county government portals, and direct research.

## Coverage Statistics
- **Total States Covered**: 50 (100%)
- **Total Counties with GIS Portals**: 296+
- **Last Updated": 2026-01-07
- **Coverage**: Complete - All 50 States

## Important Notes

This directory represents a comprehensive effort to catalog all county GIS portals in the United States. However, it's important to note:

1. **Not all counties have dedicated GIS portals** - Some smaller counties may not maintain separate GIS websites
2. **Statewide portals** - Many states provide centralized access to county data through state portals
3. **Third-party providers** - Some counties use third-party services like ESRI, Schneider Corp, or others
4. **Data availability varies** - Portal functionality ranges from basic parcel viewers to comprehensive data downloads

## File Descriptions

### 1. complete_us_county_gis_portals.json
Structured JSON file containing all GIS portal data organized by state and county with complete metadata.

### 2. complete_us_county_gis_portals.xlsx
Excel workbook with multiple sheets:
- **County GIS Portals**: Complete list of all county GIS portals with URLs and status
- **Summary by State**: Overview of counties covered per state with state portal links

### 3. complete_us_county_gis_portals.csv
CSV format for easy import into databases, GIS software, and other applications.

## State-by-State Coverage

### Northeastern States (9)
- Connecticut
- Maine
- Massachusetts
- New Hampshire
- New Jersey
- New York
- Pennsylvania
- Rhode Island
- Vermont

### Southeastern States (12)
- Alabama
- Arkansas
- Delaware
- Florida
- Georgia
- Kentucky
- Louisiana
- Mississippi
- North Carolina
- South Carolina
- Tennessee
- Virginia
- West Virginia

### Midwestern States (8)
- Illinois
- Indiana
- Iowa
- Kansas
- Michigan
- Minnesota
- Missouri
- Ohio
- Wisconsin

### Western States (11)
- Alaska
- Arizona
- California
- Colorado
- Hawaii
- Idaho
- Montana
- Nevada
- New Mexico
- Oregon
- Utah
- Washington
- Wyoming

### Great Plains States (4)
- Nebraska
- North Dakota
- Oklahoma
- South Dakota

## Key Statewide GIS Portals

| State | State Portal URL |
|-------|------------------|
| Alabama | https://www.alabamagis.com/ |
| Alaska | https://gis.data.alaska.gov/ |
| Arizona | https://azgeo.az.gov/ |
| Arkansas | https://gis.arkansas.gov/ |
| California | https://gis.data.ca.gov/ |
| Colorado | https://geodata.colorado.gov/ |
| Connecticut | https://geodata.ct.gov/ |
| Delaware | https://geodata.delaware.gov/ |
| Florida | https://geodata.floridagio.gov/ |
| Georgia | https://www.gistdata.org/ |
| Hawaii | https://geoportal.hawaii.gov/ |
| Idaho | https://gis.idaho.gov/ |
| Illinois | https://data.illinois.gov/ |
| Indiana | https://www.indianamap.org/ |
| Iowa | https://geodata.iowa.gov/ |
| Kansas | https://hub.kansasgis.org/ |
| Kentucky | https://kygeonet.ky.gov/ |
| Louisiana | https://www.louisiana.gov/ |
| Maine | https://www.maine.gov/megis/ |
| Maryland | https://data.imap.maryland.gov/ |
| Massachusetts | https://gis.data.mass.gov/ |
| Michigan | https://gis-michigan.opendata.arcgis.com/ |
| Minnesota | https://www.mngeo.state.mn.us/ |
| Mississippi | https://maris.mississippi.edu/ |
| Missouri | https://msdis.missouri.edu/ |
| Montana | https://gis-mtfwp.hub.arcgis.com/ |
| Nebraska | https://www.nebraskamap.gov/ |
| Nevada | https://gis.nv.gov/ |
| New Hampshire | https://granit.unh.edu/ |
| New Jersey | https://www.nj.gov/njgin/ |
| New Mexico | https://rgis.unm.edu/ |
| New York | https://gis.ny.gov/ |
| North Carolina | https://www.nconemap.gov/ |
| North Dakota | https://www.gis.nd.gov/ |
| Ohio | https://ogrip-geohio.opendata.arcgis.com/ |
| Oklahoma | https://www.ok.gov/gis/ |
| Oregon | https://www.oregon.gov/gis/ |
| Pennsylvania | https://www.pasda.psu.edu/ |
| Rhode Island | https://www.rigis.org/ |
| South Carolina | https://data-scdnr.opendata.arcgis.com/ |
| South Dakota | https://opendata2017-09-18t192802468z-sdbit.opendata.arcgis.com/ |
| Tennessee | https://www.tngis.org/ |
| Texas | https://gis-txdot.opendata.arcgis.com/ |
| Utah | https://gis.utah.gov/ |
| Vermont | https://vcgi.vermont.gov/ |
| Virginia | https://data.virginia.gov/ |
| Washington | https://geo.wa.gov/ |
| West Virginia | https://wvgis.wvu.edu/ |
| Wisconsin | https://maps.aqua.wisc.edu/wisconsin-ims.htm |
| Wyoming | https://data.geospatialhub.org/ |

## Data Sources

This directory was compiled from the following sources:
- State government GIS portals
- County government websites
- Academic institutions and libraries
- Federal GIS clearinghouses
- Open data portals (ArcGIS Hub, data.gov, etc.)
- Third-party GIS providers (Schneider Corp, ESRI, etc.)

## Usage Guidelines

### How to Use This Directory

1. **Start with State Portals** - Many states provide centralized access to county data
2. **Check Individual Counties** - Larger counties often have dedicated GIS departments
3. **Third-Party Providers** - Many counties use services like Beacon, Schneider Corp, or ESRI
4. **Data Access Levels** - Portal availability varies from basic viewers to full data downloads

### Portal Types

1. **Dedicated County Portals** - Full GIS departments with comprehensive data
2. **Statewide Portals** - Centralized access to multiple counties
3. **Third-Party Hosted** - Services like Beacon, ESRI, or private vendors
4. **Basic Parcel Viewers** - Simple property information tools
5. **Comprehensive Data Hubs** - Full-featured open data portals

## Data Quality and Limitations

1. **Coverage Gaps** - Not all 3,000+ counties have dedicated GIS portals
2. **Data Currency** - Update frequency varies by county and data type
3. **Access Restrictions** - Some portals require registration or payment
4. **Technical Standards** - Data formats and quality vary significantly
5. **Changing URLs** - Portal locations may change without notice

## Future Updates

This is a living document that should be updated regularly. Future updates may include:
- Additional counties as new portals become available
- More detailed metadata for each portal
- API endpoints where available
- Usage statistics and data quality indicators
- Integration with federal and tribal GIS systems

## Contributing

If you have updates, corrections, or additional county GIS portals to add, please:
1. Verify the portal URL is current and accessible
2. Note the type of data available (parcels, roads, etc.)
3. Include any access restrictions or requirements
4. Provide contact information for the GIS department if available

## Contact Information

For questions about specific portals, contact the respective county or state GIS departments. For questions about this directory, refer to the compilation methodology and sources listed above.

## Disclaimer

This directory is provided for informational purposes only. Portal availability, access levels, and data quality are subject to change without notice. Users should:

1. Verify current access and terms of use directly with each county or state agency
2. Understand that this represents a snapshot in time and may not reflect current status
3. Respect any licensing terms or usage restrictions
4. Not rely solely on this directory for critical decision-making

## License and Use

This compilation is provided as-is for public use. Individual data sources may have their own licensing terms and usage restrictions. This directory does not grant any additional rights to use the listed portals beyond what is provided by the respective data owners.

## Technical Notes

- All URLs were verified at the time of compilation
- Portal functionality may vary by browser and device
- Some portals require specific plugins or software
- Download formats vary (Shapefile, GeoJSON, CSV, etc.)
- Coordinate systems and projections vary by source

---

*This directory represents a comprehensive effort to catalog county GIS portals across the United States. Given the scale and complexity of this task, users are encouraged to verify information and report any updates or corrections.*

**Last Updated: 2026-01-07

**Total Coverage: 50 States, 296+ Counties**
