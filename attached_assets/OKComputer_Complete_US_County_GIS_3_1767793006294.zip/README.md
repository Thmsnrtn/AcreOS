# US County GIS Portal Directory

## Overview
This comprehensive directory contains GIS (Geographic Information System) portal information for counties across the United States. The data has been compiled from multiple sources including state government websites, academic institutions, and direct county resources.

## Coverage Statistics
- **Total States Covered**: 24
- **Total Counties with GIS Portals**: 155
- **Last Updated**: 2026-01-07
- **Status**: Partial - Work in Progress

## File Descriptions

### 1. us_county_gis_portals.json
Structured JSON file containing all GIS portal data organized by state and county.

### 2. us_county_gis_portals.xlsx
Excel workbook with two sheets:
- **County GIS Portals**: Complete list of all county GIS portals with URLs and status
- **Summary by State**: Overview of counties covered per state with state portal links

### 3. us_county_gis_portals.csv
CSV format for easy import into databases and other applications.

## States Covered by Region

### Northeastern States (9 states)
- Connecticut
- Maine
- Massachusetts
- New Hampshire
- New Jersey
- New York
- Pennsylvania
- Rhode Island
- Vermont

### Southeastern States (5 states)
- Florida
- Georgia
- North Carolina
- South Carolina
- Virginia

### Midwestern States (5 states)
- Colorado
- Illinois
- Indiana
- Michigan
- Ohio
- Wisconsin

### Western States (5 states)
- California
- Oregon
- Texas
- Washington

## Key Statewide GIS Portals

| State | State Portal URL |
|-------|------------------|
| California | https://gis.data.ca.gov/ |
| Colorado | https://geodata.colorado.gov/ |
| Connecticut | https://geodata.ct.gov/ |
| Florida | https://geodata.floridagio.gov/ |
| Indiana | https://www.indianamap.org/ |
| Massachusetts | https://gis.data.mass.gov/ |
| Michigan | https://gis-michigan.opendata.arcgis.com/ |
| New Hampshire | https://granit.unh.edu/ |
| New Jersey | https://www.nj.gov/njgin/ |
| New York | https://gis.ny.gov/ |
| Ohio | https://ogrip-geohio.opendata.arcgis.com/ |
| Oregon | https://www.oregon.gov/gis/ |
| Pennsylvania | https://www.pasda.psu.edu/ |
| Texas | https://gis-txdot.opendata.arcgis.com/ |
| Vermont | https://vcgi.vermont.gov/ |
| Virginia | https://data.virginia.gov/ |
| Washington | https://geo.wa.gov/ |
| Wisconsin | https://maps.aqua.wisc.edu/wisconsin-ims.htm |

## Data Sources

This directory was compiled from the following sources:
- State government GIS portals
- County government websites
- Academic institutions and libraries
- Federal GIS clearinghouses
- Open data portals

## Usage Notes

1. **Portal Availability**: Not all counties maintain dedicated GIS portals. Some use statewide systems or third-party providers.
2. **Data Access**: Access levels vary by county - some provide full downloads, others offer only web mapping services.
3. **Update Frequency**: Portal availability and URLs may change. This directory represents a snapshot as of the creation date.
4. **Authentication**: Some portals may require registration or login for full access.

## Future Updates

This is an ongoing project. Future updates will include:
- Additional states and counties
- More detailed metadata for each portal
- API endpoints where available
- Usage statistics and data quality indicators

## Contact and Contributions

If you have updates, corrections, or additional county GIS portals to add, please contact the maintainers of this directory.

## Disclaimer

This directory is provided for informational purposes only. Portal availability, access levels, and data quality are subject to change without notice. Users should verify current access and terms of use directly with each county or state agency.

## License

This compilation is provided as-is for public use. Individual data sources may have their own licensing terms and usage restrictions.
