# Advanced Land Investor Data Sources - Implementation Guide

## Quick Start Guide

This guide provides step-by-step instructions for implementing the advanced land investor data sources in your investment workflow.

## Phase 1: Foundation Setup (Week 1)

### Step 1.1: Government Data Integration

#### USDA Web Soil Survey Implementation

```python
import requests
import json

# Basic implementation for USDA soil data
def get_soil_data(lat, lon):
    """
    Retrieve soil data for specific coordinates
    """
    base_url = "https://websoilsurvey.nrcs.usda.gov/api"
    
    # First, get the survey area for these coordinates
    params = {
        'x': lon,
        'y': lat,
        'format': 'json',
        'sr': '4326'  # WGS84 coordinate system
    }
    
    try:
        response = requests.get(f"{base_url}/surveyarea", params=params)
        survey_data = response.json()
        
        # Extract soil properties
        soil_properties = {
            'texture': survey_data.get('texture', 'N/A'),
            'drainage_class': survey_data.get('drainage', 'N/A'),
            'ph': survey_data.get('ph', 'N/A'),
            'organic_matter': survey_data.get('organic_matter', 'N/A'),
            'water_holding_capacity': survey_data.get('water_holding', 'N/A')
        }
        
        return soil_properties
    except Exception as e:
        print(f"Error retrieving soil data: {e}")
        return None
```

#### FEMA Flood Data Integration

```python
def get_flood_data(address):
    """
    Retrieve FEMA flood zone data for an address
    """
    # Using National Flood Data API
    api_url = "https://www.nationalflooddata.com/dataservice/v3/"
    api_key = "YOUR_API_KEY"  # Obtain from nationalflooddata.com
    
    params = {
        'address': address,
        'key': api_key
    }
    
    try:
        response = requests.get(api_url, params=params)
        flood_data = response.json()
        
        # Extract key flood information
        flood_info = {
            'flood_zone': flood_data.get('flood_zone', 'Unknown'),
            'sfha': flood_data.get('sfha_tf', False),  # Special Flood Hazard Area
            'base_flood_elevation': flood_data.get('base_flood_elevation', 'N/A'),
            'flood_insurance_required': flood_data.get('sfha_tf', False)
        }
        
        return flood_info
    except Exception as e:
        print(f"Error retrieving flood data: {e}")
        return None
```

#### USGS Mining Claims Data

```python
def get_mining_claims(lat, lon, radius_km=10):
    """
    Retrieve active mining claims near a location
    """
    # Using USGS/BLM data through ArcGIS REST API
    base_url = "https://claims-nvdataminer.hub.arcgis.com/arcgis/rest/services"
    
    params = {
        'where': f"ST_Distance(geometry, ST_Point({lon}, {lat})) <= {radius_km * 1000}",
        'outFields': '*',
        'f': 'json'
    }
    
    try:
        response = requests.get(f"{base_url}/MiningClaims/FeatureServer/0/query", 
                              params=params)
        claims_data = response.json()
        
        claims = []
        for feature in claims_data.get('features', []):
            claim = {
                'claim_name': feature['attributes'].get('CLAIM_NAME', 'Unknown'),
                'claim_type': feature['attributes'].get('CLAIM_TYPE', 'Unknown'),
                'status': feature['attributes'].get('STATUS', 'Unknown'),
                'discovery_date': feature['attributes'].get('DISCOVERY_DATE', 'N/A')
            }
            claims.append(claim)
        
        return claims
    except Exception as e:
        print(f"Error retrieving mining claims: {e}")
        return []
```

### Step 1.2: Data Storage Setup

```python
import sqlite3
from datetime import datetime

def setup_database():
    """
    Initialize database for storing land investment data
    """
    conn = sqlite3.connect('land_investment_data.db')
    cursor = conn.cursor()
    
    # Create properties table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS properties (
            id INTEGER PRIMARY KEY,
            address TEXT NOT NULL,
            lat REAL,
            lon REAL,
            created_date TIMESTAMP,
            soil_data TEXT,
            flood_data TEXT,
            mining_claims TEXT
        )
    ''')
    
    # Create data sources table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS data_sources (
            id INTEGER PRIMARY KEY,
            property_id INTEGER,
            source_name TEXT,
            data_type TEXT,
            api_response TEXT,
            retrieved_date TIMESTAMP,
            FOREIGN KEY (property_id) REFERENCES properties (id)
        )
    ''')
    
    conn.commit()
    return conn
```

## Phase 2: Advanced Analytics (Week 2)

### Step 2.1: Satellite Imagery Integration

#### Sentinel Hub API Implementation

```python
from sentinelhub import SentinelHubRequest, DataCollection, MimeType

def get_satellite_imagery(lat, lon, date_range):
    """
    Retrieve satellite imagery for change detection
    """
    # Configure Sentinel Hub credentials
    config = {
        'instance_id': 'YOUR_INSTANCE_ID',
        'client_id': 'YOUR_CLIENT_ID',
        'client_secret': 'YOUR_CLIENT_SECRET'
    }
    
    # Define area of interest
    bbox = [lon-0.01, lat-0.01, lon+0.01, lat+0.01]  # ~1km area
    
    request = SentinelHubRequest(
        data_folder='./satellite_data',
        evalscript='''
        //VERSION=3
        function setup() {
            return {
                input: [{"bands": ["B02", "B03", "B04", "B08"]}],
                output: { bands: 4 }
            };
        }
        
        function evaluatePixel(sample) {
            return [sample.B04, sample.B03, sample.B02, sample.B08];
        }
        ''',
        input_data=[
            SentinelHubRequest.input_data(
                data_collection=DataCollection.SENTINEL2_L1C,
                time_interval=date_range,
                maxcc=0.3  # Max 30% cloud coverage
            )
        ],
        responses=[
            SentinelHubRequest.output_response('default', MimeType.TIFF)
        ],
        bbox=bbox,
        size=(512, 512),
        config=config
    )
    
    return request.get_data()
```

#### Change Detection Analysis

```python
import numpy as np
from scipy import ndimage

def detect_changes(image1_path, image2_path):
    """
    Detect changes between two satellite images
    """
    from PIL import Image
    
    # Load images
    img1 = np.array(Image.open(image1_path))
    img2 = np.array(Image.open(image2_path))
    
    # Calculate difference
    diff = np.abs(img1.astype(float) - img2.astype(float))
    
    # Apply threshold to identify significant changes
    threshold = np.percentile(diff, 95)  # Top 5% of changes
    significant_changes = diff > threshold
    
    # Calculate change statistics
    change_percentage = np.sum(significant_changes) / significant_changes.size * 100
    
    # Apply morphological operations to clean up noise
    cleaned_changes = ndimage.binary_opening(significant_changes, structure=np.ones((3,3)))
    
    return {
        'change_percentage': change_percentage,
        'change_mask': cleaned_changes,
        'visualization': diff
    }
```

### Step 2.2: AI Valuation Integration

#### Zillow Zestimate API

```python
def get_zestimate(property_id):
    """
    Retrieve Zillow Zestimate for a property
    """
    api_url = "https://api.bridgedataoutput.com/api/zillow"
    api_key = "YOUR_API_KEY"
    
    headers = {
        'Authorization': f'Bearer {api_key}'
    }
    
    params = {
        'id': property_id,
        'view': 'detail'
    }
    
    try:
        response = requests.get(f"{api_url}/property", headers=headers, params=params)
        property_data = response.json()
        
        zestimate_data = {
            'zestimate': property_data.get('zestimate', 0),
            'price_history': property_data.get('price_history', []),
            'market_value': property_data.get('market_value', 0),
            'confidence_score': property_data.get('confidence_score', 0)
        }
        
        return zestimate_data
    except Exception as e:
        print(f"Error retrieving Zestimate: {e}")
        return None
```

#### Homesage.ai Integration

```python
def get_homesage_valuation(address):
    """
    Retrieve AI-powered valuation from Homesage.ai
    """
    api_url = "https://api.homesage.ai/v1"
    api_key = "YOUR_API_KEY"
    
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'address': address,
        'include_market_analysis': True,
        'include_investment_score': True
    }
    
    try:
        response = requests.post(f"{api_url}/property/valuation", 
                               headers=headers, json=data)
        valuation_data = response.json()
        
        return {
            'estimated_value': valuation_data.get('estimated_value', 0),
            'investment_score': valuation_data.get('investment_score', 0),
            'market_analysis': valuation_data.get('market_analysis', {}),
            'confidence_level': valuation_data.get('confidence_level', 0)
        }
    except Exception as e:
        print(f"Error retrieving Homesage valuation: {e}")
        return None
```

### Step 2.3: Sentiment Analysis Implementation

#### Market Sentiment Monitoring

```python
def analyze_market_sentiment(region, keywords):
    """
    Analyze sentiment for a specific region and keywords
    """
    from textblob import TextBlob
    import feedparser
    
    # News sources to monitor
    news_sources = [
        'https://news.google.com/rss/search?q={}+real+estate'.format(region.replace(' ', '+')),
        'https://feeds.realtor.com/news/rss'
    ]
    
    all_sentiment = []
    
    for source in news_sources:
        try:
            feed = feedparser.parse(source)
            
            for entry in feed.entries[:10]:  # Limit to recent 10 articles
                # Check if keywords are mentioned
                if any(keyword.lower() in entry.title.lower() or 
                       keyword.lower() in entry.summary.lower() 
                       for keyword in keywords):
                    
                    # Analyze sentiment
                    blob = TextBlob(entry.title + ' ' + entry.summary)
                    sentiment_score = blob.sentiment.polarity
                    
                    all_sentiment.append({
                        'title': entry.title,
                        'sentiment_score': sentiment_score,
                        'published': entry.published,
                        'source': source
                    })
        except Exception as e:
            print(f"Error processing {source}: {e}")
    
    # Calculate average sentiment
    if all_sentiment:
        avg_sentiment = sum(s['sentiment_score'] for s in all_sentiment) / len(all_sentiment)
        return {
            'average_sentiment': avg_sentiment,
            'sentiment_trend': 'Positive' if avg_sentiment > 0.1 else 'Negative' if avg_sentiment < -0.1 else 'Neutral',
            'articles_analyzed': len(all_sentiment),
            'detailed_results': all_sentiment
        }
    
    return None
```

## Phase 3: Data Integration & Analysis (Week 3)

### Step 3.1: Comprehensive Property Analysis

```python
def comprehensive_property_analysis(address, lat, lon):
    """
    Perform comprehensive analysis of a property using all data sources
    """
    analysis_results = {
        'address': address,
        'coordinates': {'lat': lat, 'lon': lon},
        'analysis_date': datetime.now(),
        'data_sources': {}
    }
    
    # 1. Government Data
    print("Analyzing government data...")
    analysis_results['data_sources']['soil'] = get_soil_data(lat, lon)
    analysis_results['data_sources']['flood'] = get_flood_data(address)
    analysis_results['data_sources']['mining_claims'] = get_mining_claims(lat, lon)
    
    # 2. AI Valuations
    print("Getting AI valuations...")
    analysis_results['data_sources']['zestimate'] = get_zestimate(address)
    analysis_results['data_sources']['homesage'] = get_homesage_valuation(address)
    
    # 3. Satellite Analysis
    print("Analyzing satellite imagery...")
    date_range = ('2023-01-01', '2024-01-01')
    satellite_images = get_satellite_imagery(lat, lon, date_range)
    if satellite_images:
        analysis_results['data_sources']['satellite_change'] = detect_changes(
            satellite_images[0], satellite_images[-1]
        )
    
    # 4. Market Sentiment
    print("Analyzing market sentiment...")
    region = address.split(', ')[-2]  # Extract city/county
    keywords = ['land', 'development', 'investment', 'growth']
    analysis_results['data_sources']['sentiment'] = analyze_market_sentiment(region, keywords)
    
    # Generate overall investment score
    analysis_results['investment_score'] = calculate_investment_score(analysis_results)
    
    return analysis_results

def calculate_investment_score(analysis_results):
    """
    Calculate an overall investment score based on all available data
    """
    score = 50  # Starting neutral score
    
    # Soil quality (0-20 points)
    soil_data = analysis_results['data_sources'].get('soil', {})
    if soil_data:
        # Better soil = higher score
        if soil_data.get('texture') in ['loam', 'silt loam']:
            score += 15
        elif soil_data.get('drainage_class') == 'well_drained':
            score += 10
    
    # Flood risk (0-20 points)
    flood_data = analysis_results['data_sources'].get('flood', {})
    if flood_data:
        if not flood_data.get('sfha', True):  # Not in flood zone
            score += 20
        elif flood_data.get('flood_zone') in ['X', 'C']:
            score += 15
    
    # AI valuations (0-20 points)
    zestimate = analysis_results['data_sources'].get('zestimate', {})
    homesage = analysis_results['data_sources'].get('homesage', {})
    if zestimate and homesage:
        # Higher confidence scores = higher investment score
        confidence = (zestimate.get('confidence_score', 0) + 
                     homesage.get('confidence_level', 0)) / 2
        score += confidence * 20
    
    # Market sentiment (0-20 points)
    sentiment = analysis_results['data_sources'].get('sentiment', {})
    if sentiment:
        score += (sentiment.get('average_sentiment', 0) + 1) * 10  # Scale to 0-20
    
    # Satellite change detection (0-20 points)
    change_data = analysis_results['data_sources'].get('satellite_change', {})
    if change_data:
        # Low change percentage = more stable investment
        change_pct = change_data.get('change_percentage', 0)
        if change_pct < 5:
            score += 20
        elif change_pct < 10:
            score += 15
        else:
            score += 5  # High change could indicate development
    
    return min(100, max(0, score))  # Ensure score is between 0-100
```

### Step 3.2: Automated Monitoring System

```python
import schedule
import time
from datetime import datetime, timedelta

def setup_monitoring_system(properties):
    """
    Set up automated monitoring for a list of properties
    """
    
    def daily_analysis():
        """Run daily analysis on all monitored properties"""
        print(f"Running daily analysis at {datetime.now()}")
        
        for prop in properties:
            try:
                # Perform comprehensive analysis
                results = comprehensive_property_analysis(
                    prop['address'], prop['lat'], prop['lon']
                )
                
                # Save results to database
                save_analysis_results(results)
                
                # Check for significant changes
                check_for_significant_changes(results)
                
            except Exception as e:
                print(f"Error analyzing {prop['address']}: {e}")
    
    def weekly_sentiment_analysis():
        """Run weekly sentiment analysis"""
        print(f"Running weekly sentiment analysis at {datetime.now()}")
        
        # Analyze sentiment for all unique regions
        regions = set(prop['address'].split(', ')[-2] for prop in properties)
        
        for region in regions:
            keywords = ['land', 'development', 'investment', 'growth']
            sentiment = analyze_market_sentiment(region, keywords)
            
            if sentiment and abs(sentiment['average_sentiment']) > 0.2:
                # Significant sentiment change detected
                send_alert(f"Market sentiment change detected in {region}: {sentiment['sentiment_trend']}")
    
    def monthly_satellite_update():
        """Run monthly satellite imagery analysis"""
        print(f"Running monthly satellite update at {datetime.now()}")
        
        for prop in properties:
            try:
                # Get recent satellite imagery
                end_date = datetime.now()
                start_date = end_date - timedelta(days=30)
                
                satellite_images = get_satellite_imagery(
                    prop['lat'], prop['lon'], 
                    (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
                )
                
                if satellite_images:
                    # Compare with previous month's imagery
                    # (Implementation would compare with stored baseline)
                    pass
                    
            except Exception as e:
                print(f"Error updating satellite data for {prop['address']}: {e}")
    
    # Schedule tasks
    schedule.every().day.at("09:00").do(daily_analysis)
    schedule.every().monday.at("10:00").do(weekly_sentiment_analysis)
    schedule.every().month.do(monthly_satellite_update)
    
    print("Monitoring system initialized")
    
    # Start the monitoring loop
    while True:
        schedule.run_pending()
        time.sleep(60)  # Check every minute

def check_for_significant_changes(analysis_results):
    """
    Check if recent analysis shows significant changes from baseline
    """
    # This would compare with historical data stored in database
    # Implementation would depend on specific business rules
    
    investment_score = analysis_results.get('investment_score', 50)
    
    if investment_score > 80:
        send_alert(f"High investment opportunity detected: {analysis_results['address']} (Score: {investment_score})")
    elif investment_score < 30:
        send_alert(f"Investment risk detected: {analysis_results['address']} (Score: {investment_score})")

def send_alert(message):
    """
    Send alert notification (email, SMS, push notification)
    """
    print(f"ALERT: {message}")
    # Implementation would integrate with notification services
    # (Twilio for SMS, SendGrid for email, etc.)
```

## Phase 4: Dashboard & Reporting (Week 4)

### Step 4.1: Create Web Dashboard

```python
from flask import Flask, render_template, jsonify
import json

app = Flask(__name__)

@app.route('/')
def dashboard():
    """Main dashboard showing all properties"""
    properties = get_monitored_properties()
    return render_template('dashboard.html', properties=properties)

@app.route('/api/property/<int:property_id>')
def property_details(property_id):
    """Get detailed analysis for a specific property"""
    analysis = get_latest_analysis(property_id)
    return jsonify(analysis)

@app.route('/api/alerts')
def get_alerts():
    """Get recent alerts and notifications"""
    alerts = get_recent_alerts(limit=10)
    return jsonify(alerts)

@app.route('/api/market-sentiment')
def market_sentiment():
    """Get overall market sentiment analysis"""
    sentiment_data = get_market_sentiment_summary()
    return jsonify(sentiment_data)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

### Step 4.2: Generate Investment Reports

```python
def generate_investment_report(property_ids, report_type='comprehensive'):
    """
    Generate detailed investment report for specified properties
    """
    report = {
        'generated_date': datetime.now(),
        'report_type': report_type,
        'properties': [],
        'summary': {}
    }
    
    total_score = 0
    property_count = 0
    
    for property_id in property_ids:
        # Get latest analysis
        analysis = get_latest_analysis(property_id)
        
        if analysis:
            property_info = {
                'address': analysis['address'],
                'coordinates': analysis['coordinates'],
                'investment_score': analysis.get('investment_score', 0),
                'data_sources': analysis['data_sources']
            }
            
            report['properties'].append(property_info)
            total_score += property_info['investment_score']
            property_count += 1
    
    # Calculate summary statistics
    if property_count > 0:
        report['summary'] = {
            'total_properties': property_count,
            'average_score': total_score / property_count,
            'top_properties': sorted(report['properties'], 
                                   key=lambda x: x['investment_score'], 
                                   reverse=True)[:5],
            'recommendations': generate_recommendations(report['properties'])
        }
    
    return report

def generate_recommendations(properties):
    """
    Generate investment recommendations based on analysis
    """
    recommendations = []
    
    for prop in properties:
        score = prop['investment_score']
        
        if score >= 80:
            recommendations.append({
                'address': prop['address'],
                'recommendation': 'STRONG BUY',
                'rationale': 'High investment score indicates excellent opportunity',
                'priority': 'High'
            })
        elif score >= 60:
            recommendations.append({
                'address': prop['address'],
                'recommendation': 'BUY',
                'rationale': 'Good investment potential with manageable risks',
                'priority': 'Medium'
            })
        elif score >= 40:
            recommendations.append({
                'address': prop['address'],
                'recommendation': 'HOLD',
                'rationale': 'Moderate investment potential, consider alternatives',
                'priority': 'Low'
            })
        else:
            recommendations.append({
                'address': prop['address'],
                'recommendation': 'AVOID',
                'rationale': 'High risk or low potential return',
                'priority': 'High'
            })
    
    return recommendations
```

## Best Practices & Optimization

### Error Handling

```python
import logging
from functools import wraps

def retry_on_failure(max_retries=3, delay=1):
    """Decorator for retrying failed API calls"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    logging.warning(f"Attempt {attempt + 1} failed: {e}")
                    if attempt < max_retries - 1:
                        time.sleep(delay * (attempt + 1))  # Exponential backoff
                    else:
                        logging.error(f"All {max_retries} attempts failed")
                        raise
        return wrapper
    return decorator

@retry_on_failure(max_retries=3)
def reliable_api_call(url, params=None):
    """API call with built-in retry logic"""
    response = requests.get(url, params=params, timeout=30)
    response.raise_for_status()
    return response.json()
```

### Caching Strategy

```python
import redis
import pickle
from functools import lru_cache

# Set up Redis for caching
redis_client = redis.Redis(host='localhost', port=6379, db=0)

def cache_api_response(expiration_time=3600):
    """Decorator for caching API responses"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key from function arguments
            cache_key = f"{func.__name__}:{str(args)}:{str(kwargs)}"
            
            # Try to get from cache
            cached_result = redis_client.get(cache_key)
            if cached_result:
                return pickle.loads(cached_result)
            
            # Call function and cache result
            result = func(*args, **kwargs)
            redis_client.setex(cache_key, expiration_time, pickle.dumps(result))
            return result
        return wrapper
    return decorator

@cache_api_response(expiration_time=7200)  # Cache for 2 hours
def cached_soil_data(lat, lon):
    """Cached version of soil data retrieval"""
    return get_soil_data(lat, lon)
```

### Performance Monitoring

```python
import time
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class PerformanceMetric:
    function_name: str
    execution_time: float
    success: bool
    error_message: str = None

performance_metrics: List[PerformanceMetric] = []

def monitor_performance(func):
    """Decorator for monitoring function performance"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        success = True
        error_msg = None
        
        try:
            result = func(*args, **kwargs)
        except Exception as e:
            success = False
            error_msg = str(e)
            raise
        finally:
            execution_time = time.time() - start_time
            metric = PerformanceMetric(
                function_name=func.__name__,
                execution_time=execution_time,
                success=success,
                error_message=error_msg
            )
            performance_metrics.append(metric)
            
            # Log slow functions
            if execution_time > 5.0:  # 5 seconds
                logging.warning(f"Slow function detected: {func.__name__} took {execution_time:.2f}s")
        
        return result
    return wrapper

def get_performance_report():
    """Generate performance report"""
    if not performance_metrics:
        return "No performance data available"
    
    total_calls = len(performance_metrics)
    successful_calls = sum(1 for m in performance_metrics if m.success)
    avg_execution_time = sum(m.execution_time for m in performance_metrics) / total_calls
    
    report = f"""
    Performance Report:
    - Total API calls: {total_calls}
    - Success rate: {successful_calls/total_calls*100:.1f}%
    - Average execution time: {avg_execution_time:.2f}s
    - Slowest call: {max(m.execution_time for m in performance_metrics):.2f}s
    - Fastest call: {min(m.execution_time for m in performance_metrics):.2f}s
    """
    
    return report
```

## Testing & Validation

### Unit Tests

```python
import unittest
from unittest.mock import patch, MagicMock

class TestLandInvestmentAPIs(unittest.TestCase):
    
    def test_soil_data_retrieval(self):
        """Test soil data API integration"""
        # Mock API response
        mock_response = {
            'texture': 'loam',
            'drainage_class': 'well_drained',
            'ph': 6.5
        }
        
        with patch('requests.get') as mock_get:
            mock_get.return_value.json.return_value = mock_response
            mock_get.return_value.status_code = 200
            
            result = get_soil_data(40.7128, -74.0060)  # NYC coordinates
            
            self.assertIsNotNone(result)
            self.assertEqual(result['texture'], 'loam')
            self.assertEqual(result['drainage_class'], 'well_drained')
    
    def test_flood_data_retrieval(self):
        """Test flood data API integration"""
        mock_response = {
            'flood_zone': 'X',
            'sfha_tf': False,
            'base_flood_elevation': None
        }
        
        with patch('requests.get') as mock_get:
            mock_get.return_value.json.return_value = mock_response
            mock_get.return_value.status_code = 200
            
            result = get_flood_data("123 Main St, Anytown, ST 12345")
            
            self.assertIsNotNone(result)
            self.assertEqual(result['flood_zone'], 'X')
            self.assertFalse(result['sfha_tf'])
    
    def test_investment_score_calculation(self):
        """Test investment score calculation logic"""
        mock_analysis = {
            'data_sources': {
                'soil': {'texture': 'loam', 'drainage_class': 'well_drained'},
                'flood': {'sfha_tf': False},
                'zestimate': {'confidence_score': 0.8},
                'homesage': {'confidence_level': 0.9},
                'sentiment': {'average_sentiment': 0.2},
                'satellite_change': {'change_percentage': 3}
            }
        }
        
        score = calculate_investment_score(mock_analysis)
        
        self.assertGreater(score, 70)  # Should be high with good data
        self.assertLessEqual(score, 100)  # Should not exceed 100

if __name__ == '__main__':
    unittest.main()
```

## Deployment Checklist

### Pre-Deployment

- [ ] All API keys and credentials secured
- [ ] Database properly configured with backups
- [ ] Error handling and logging implemented
- [ ] Performance monitoring in place
- [ ] Security measures implemented (HTTPS, authentication)
- [ ] Documentation updated
- [ ] Tests passing with >80% coverage

### Production Environment

- [ ] Server capacity planned for expected load
- [ ] Load balancing configured if needed
- [ ] SSL certificates installed
- [ ] Domain names configured
- [ ] Email/SMS services configured for alerts
- [ ] Monitoring and alerting systems active
- [ ] Backup procedures tested

### Post-Deployment

- [ ] Monitor system performance
- [ ] Verify all data sources are working
- [ ] Test alert notifications
- [ ] Collect user feedback
- [ ] Plan for future enhancements

## Troubleshooting Common Issues

### API Rate Limits
**Problem**: Hitting rate limits on APIs
**Solution**: Implement caching, request queuing, and upgrade API plans if needed

### Data Inconsistencies
**Problem**: Different data sources provide conflicting information
**Solution**: Implement data validation rules and weight sources by reliability

### Slow Performance
**Problem**: Analysis takes too long to complete
**Solution**: Implement caching, optimize database queries, use background processing

### Authentication Failures
**Problem**: API credentials expire or get revoked
**Solution**: Implement credential rotation and automated renewal processes

### Data Quality Issues
**Problem**: Incomplete or inaccurate data from APIs
**Solution**: Implement data validation, fallback sources, and quality scoring

## Support and Maintenance

### Regular Maintenance Tasks

1. **Daily**: Monitor API health and system performance
2. **Weekly**: Review and analyze performance metrics
3. **Monthly**: Update API credentials and review data quality
4. **Quarterly**: Assess new data sources and plan enhancements

### Getting Help

- **API Documentation**: Always refer to official API docs first
- **Community Forums**: Stack Overflow, Reddit r/realestateinvesting
- **Professional Support**: Consider hiring data science consultants
- **Legal Advice**: Consult real estate attorneys for complex transactions

---

This implementation guide provides a complete roadmap for integrating advanced land investor data sources into your investment workflow. Start with Phase 1 and progressively add capabilities as you become comfortable with each component.