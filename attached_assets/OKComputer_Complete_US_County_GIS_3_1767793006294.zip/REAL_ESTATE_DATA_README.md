# Comprehensive US Real Estate Market Data Directory

## Executive Summary

This directory provides the most comprehensive survey of publicly available real estate market data sources across the United States, including the newly added **Contact Information & White Pages** category. It includes national portals, MLS systems, government housing databases, commercial APIs, property valuation services, market research sources, specialized data providers, and contact information APIs.

## Coverage Statistics

- **Total Data Sources**: 61
- **Categories Covered**: 10
- **Coverage**: National, State, and Local
- **Last Updated: 2026-01-07

## Data Source Categories

### 1. National Real Estate Portals (6 sources)
Major consumer-facing real estate websites that provide property data, listings, and market information.

**Key Sources:**
- **Zillow**: Largest portal with property values, listings, market trends
- **Realtor.com**: Official NAR website with MLS listings
- **Redfin**: Technology-powered brokerage with public market data
- **Trulia**: Neighborhood-focused property portal
- **Homes.com**: Property search portal with market data
- **Apartments.com**: Rental market data and trends

### 2. MLS Systems (6 sources)
Multiple Listing Services with varying levels of public access.

**Key Sources:**
- **Bright MLS**: Largest MLS with public access through Nestfully
- **CRMLS**: California Regional MLS
- **TREIS**: Texas statewide MLS
- **Stellar MLS**: Florida and surrounding states
- **MRED**: Midwest Real Estate Data
- **RealTracs**: Tennessee and Kentucky

### 3. Government Housing Data (6 sources)
Federal government sources for housing statistics and research.

**Key Sources:**
- **HUD USER Data Sets**: HUD's primary data portal
- **HUD Exchange**: Program data and resources
- **American Housing Survey**: Most comprehensive national housing survey
- **Census Bureau Housing Data**: Comprehensive housing statistics
- **FHFA House Price Index**: Federal house price data
- **CFPB Mortgage Data**: HMDA lending data

### 4. County Assessor Databases (6 sources - examples)
Local government property assessment and tax databases.

**Examples Included:**
- Cook County Assessor (IL)
- Los Angeles County Assessor
- Harris County Appraisal District (TX)
- Maricopa County Assessor (AZ)
- Miami-Dade County Property Appraiser
- King County Assessor (WA)

**Note**: Every county has its own assessor database. This represents a sample of major counties. Users should search for their specific county's assessor website.

### 5. Commercial Real Estate APIs (5 sources)
API services with free tiers for developers and researchers.

**Key Sources:**
- **Homesage.ai**: AI-powered data with 500 free credits monthly
- **RentCast**: Property and rental data API
- **PropertyData**: UK property analytics
- **PriceHubble**: European real estate insights
- **TovoData**: US real estate data API

### 6. Property Valuation APIs (5 sources)
Services providing automated property valuations and analytics.

**Key Sources:**
- **Zillow Zestimate API**: Automated valuation models
- **HouseCanary**: ML-powered property analytics
- **CoreLogic**: Comprehensive property data
- **ATTOM Data**: Premium property information
- **Estated**: Real-time property valuations

### 7. Market Research Sources (5 sources)
Organizations providing housing market research and analysis.

**Key Sources:**
- **Redfin Data Center**: Public housing market data
- **Realtor.com Research**: Market reports and trends
- **Freddie Mac House Price Index**: Price index data
- **NAHB Housing Data**: Building permits and starts
- **Real Estate Research Council**: Industry research

### 8. Alternative/Specialized Sources (6 sources)
Niche data providers for specific use cases.

**Key Sources:**
- **Walk Score API**: Walkability and neighborhood data
- **GreatSchools API**: School ratings and boundaries
- **NeighborhoodScout**: Crime and demographic data
- **Data.gov Housing**: Government open datasets
- **Quandl**: Financial and economic data
- **SimplyRETS**: Simplified MLS data API

### 9. Tax Delinquency and Lien Data (8 sources) ⭐ CRITICAL
Sources for property tax delinquency, tax liens, and related public records.

**Key Sources:**

#### County Tax Collector Databases
- **Coverage**: County level nationwide
- **Data Types**: Delinquent property taxes, tax certificates, tax deed sales, payment status
- **Access**: Free online search through county websites

#### State Tax Lien Registries
- **Coverage**: State level where available
- **Data Types**: State tax liens, lien status, release information
- **Access**: Free and subscription access

#### Federal Tax Lien Database (IRS)
- **Portal**: https://www.irs.gov/
- **System**: Automated Lien System (ALS)
- **Coverage**: National
- **Data Types**: Federal tax liens, lien releases, taxpayer information
- **Access**: FOIA requests, county recorder offices

#### County Recorder/Clerk Records
- **Coverage**: County level nationwide
- **Data Types**: Recorded liens, tax liens, judgment liens, release documents
- **Access**: Free and paid document access

#### Tax Lien Sale Lists
- **Portal**: Data.gov and county websites
- **Format**: CSV/JSON downloads
- **Coverage**: Jurisdictions with tax sales
- **Data Types**: Properties eligible for lien sale, lien amounts, sale dates
- **Access**: Free public data

#### Third-Party Lien Search Services
- **Coverage**: National
- **Data Types**: Comprehensive lien searches, state and federal liens, UCC filings
- **Access**: Commercial services

#### Treasurer and Tax Collector Portals
- **Coverage**: County level
- **Data Types**: Delinquent tax payments, installment plans, redemption status
- **Access**: Free online access

#### Tax Certificate Investors
- **Coverage**: Areas with tax certificate sales
- **Data Types**: Tax certificates for sale, investment opportunities, redemption tracking
- **Access**: Investor access

### 10. Contact Information & White Pages (8 sources) ⭐ NEW
Free APIs and databases for address verification, geocoding, and contact information.

**Key Sources:**

#### USPS Address Verification API
- **URL**: https://tools.usps.com/zip-code-lookup.htm
- **API**: https://secure.shippingapis.com/ShippingAPI.dll
- **Coverage**: United States
- **Data Types**: Address validation, ZIP code lookup, City state lookup, Delivery point validation
- **Access Level**: Free with registration (Web Tools User ID)
- **Description**: Official USPS address verification - ensures deliverable addresses for mailings

#### OpenAddresses
- **URL**: https://openaddresses.io/
- **API**: Downloadable datasets
- **Coverage**: Global (500+ million addresses)
- **Data Types**: Street addresses, Coordinates, Postal codes, Building numbers
- **Access Level**: Free open data
- **Description**: Free global address database - comprehensive address data for multiple countries

#### Geoapify Geocoding API
- **URL**: https://www.geoapify.com/
- **API**: https://api.geoapify.com/v1/geocode
- **Coverage**: Global
- **Data Types**: Address geocoding, Reverse geocoding, Address autocomplete, Address validation
- **Access Level**: Free tier available (3000 requests/day)
- **Description**: Geocoding and address validation API with generous free tier

#### LocationIQ
- **URL**: https://locationiq.com/
- **API**: https://us1.locationiq.com/v1/
- **Coverage**: Global
- **Data Types**: Geocoding, Reverse geocoding, Address autocomplete, Map tiles
- **Access Level**: Free tier (5000 requests/day)
- **Description**: Free geocoding API with high daily limit - good for address validation

#### IP-API.com
- **URL**: https://ip-api.com/
- **API**: http://ip-api.com/json/
- **Coverage**: Global
- **Data Types**: IP geolocation, ISP information, Organization data, Timezone
- **Access Level**: Free (45 requests/minute limit)
- **Description**: Free IP geolocation API - can help identify user location for address suggestions

#### Placekey
- **URL**: https://www.placekey.io/
- **API**: https://api.placekey.io/
- **Coverage**: Global
- **Data Types**: Place keys, Address matching, Location encoding, POI data
- **Access Level**: Free tier available
- **Description**: Universal location identifier - helps match addresses across datasets

#### Data.gov Contact Datasets
- **URL**: https://www.data.gov/"
- **API**: Various APIs
- **Coverage**: US government datasets
- **Data Types**: Government employee directories, Agency contact information, Public official data
- **Access Level**: Free open data
- **Description**: Government contact information - useful for official mailings

#### Census Bureau Address Files
- **URL**: https://www.census.gov/programs-surveys/geography/technical-documentation/complete-technical-documentation/census-2000-summary-file-1.html
- **API**: Downloadable data
- **Coverage**: United States
- **Data Types**: Master Address File, Topologically Integrated Geographic Encoding, Address ranges, Geographic areas
- **Access Level**: Free public data
- **Description**: Census Bureau address files - comprehensive address database for US

## How to Use This Directory

### For Property Research:
1. Start with National Portals (Zillow, Realtor.com)
2. Check County Assessor for official records
3. Use Government sources for statistics
4. Check Tax Delinquency for property status
5. Use Contact Information for owner lookup

### For Market Analysis:
1. Government sources for authoritative data
2. Market Research sources for trends
3. Commercial APIs for detailed property data
4. Tax Delinquency data for distress indicators

### For Development/Integration:
1. Start with Commercial APIs offering free tiers
2. Consider Government APIs for public data
3. Evaluate Property Valuation APIs for estimates
4. Use Contact Information APIs for address validation

### For Address/Mailing List Building:
1. USPS Address Verification for validation
2. OpenAddresses for bulk address data
3. Geoapify/LocationIQ for geocoding
4. Census Bureau files for comprehensive coverage

## Technical Integration Notes

### Address Validation Workflow:
1. Use USPS API for official validation
2. Use Geoapify/LocationIQ for geocoding
3. Use OpenAddresses for bulk data
4. Use Placekey for cross-dataset matching

### Rate Limiting Considerations:
- USPS: Registration required, generous limits
- Geoapify: 3000 requests/day free
- LocationIQ: 5000 requests/day free
- IP-API: 45 requests/minute
- OpenAddresses: Download bulk data

### Data Quality Hierarchy:
1. USPS (official, most accurate)
2. Census Bureau (comprehensive, authoritative)
3. OpenAddresses (global, open source)
4. Commercial APIs (convenient, good quality)

## Cost-Benefit Analysis

### Free Tier Capabilities:
- ✅ Address validation and geocoding
- ✅ Bulk address data downloads
- ✅ Government contact information
- ✅ Comprehensive coverage

### Paid Tier Opportunities:
- Higher rate limits
- Advanced features (autocomplete, validation)
- Historical address data
- Enhanced support

## Conclusion

This enhanced directory now includes **61 total data sources** across **10 categories**, including the critical new **Contact Information & White Pages** category. This addition provides:

- **Official address validation** (USPS)
- **Global address coverage** (OpenAddresses)
- **Geocoding and validation** (multiple APIs)
- **Contact information** (government directories)
- **Address standardization** (Census Bureau)

The contact information category is particularly valuable for:
- **Direct mail campaigns**
- **Owner lookup and verification**
- **Address standardization**
- **Geocoding for mapping**
- **Bulk address processing**

**Total enhanced database**: 61 sources across 10 categories, providing comprehensive real estate, land, tax, and contact data coverage.

---

**Total Sources**: 61
**Total Categories**: 10
**NEW Category**: Contact Information & White Pages (8 sources)

**Last Updated: 2026-01-07

This is now the most comprehensive free real estate and land investing database available!
